package com.sp.app.common.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository("dao")
public class MyBatisDaoImpl implements CommonDAO {
	@Autowired
	private SqlSession sqlSession;
	
	private final Logger logger=LoggerFactory.getLogger(getClass());
	
/*	
	public void setSqlSessionTemplate(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
*/
	
	// ******************************************************************
	// �뜲�씠�꽣 異붽�
    public int insertData(String id, Object value) throws Exception {
    	int result = 0;

		try {
			result = sqlSession.insert(id, value);
		} catch (Exception e) {
			logger.error(e.toString());
			
			throw e;
		} finally {
		}
		return result;
    }
    
    public int insertData(String id) throws Exception {
    	int result = 0;

		try {
			result = sqlSession.insert(id);
		} catch (Exception e) {
			logger.error(e.toString());
			
			throw e;
		} finally {
		}
		return result;
    }
    
	// ******************************************************************
	// �뜲�씠�꽣 �닔�젙
    public int updateData(String id, Object value) throws Exception {
		int result = 0;
		
		try {
	   	    result = sqlSession.update(id, value);
		} catch (Exception e) {
			logger.error(e.toString());
			
			throw e;
		}
		
		return result;
    }
    
    public int updateData(String id) throws Exception {
		int result = 0;
		
		try {
	   	    result = sqlSession.update(id);
		} catch (Exception e) {
			logger.error(e.toString());
			
			throw e;
		}
		
		return result;
    }
    
	// ******************************************************************
	// �뜲�씠�꽣 �궘�젣
	public int deleteData(String id, Object value) throws Exception {
		int result = 0;
		
		try {
			result = sqlSession.delete(id, value);
		} catch (Exception e) {
			logger.error(e.toString());
			
			throw e;
		}

		return result;
    }
	
	public int deleteData(String id) throws Exception {
		int result = 0;
		
		try {
	    	result = sqlSession.delete(id);
		} catch (Exception e) {
			logger.error(e.toString());
			
			throw e;
		}

		return result;
    }
	
	// ******************************************************************
	// �뀒�씠釉붿쓽 �븯�굹 �씠�긽�쓽 �젅肄붾뱶瑜� SELECT
	public <T> List<T> selectList(String id, Object value) throws Exception {
		List<T> list = null;
		try {
			list = sqlSession.selectList(id, value);
		} catch (Exception e) {
			logger.error(e.toString());
			
			throw e;
		}		
		return list;
	
	}
	public <T> List<T> selectList(String id) throws Exception {
		List<T> list = null;
		try {
			list = sqlSession.selectList(id);
		} catch (Exception e) {
			logger.error(e.toString());
			
			throw e;
		}		
		return list;
	}
	
	// ******************************************************************
	// �뀒�씠釉붿쓽 �븯�굹�쓽 �젅肄붾뱶瑜� SELECT
	public <T> T selectOne(String id, Object value) throws Exception {
		try {
			return  sqlSession.selectOne(id, value);
		} catch (Exception e) {
			logger.error(e.toString());
			
			throw e;
		}		
	}

	public <T> T selectOne(String id) throws Exception {
		try {
			return  sqlSession.selectOne(id);
		} catch (Exception e) {
			logger.error(e.toString());
			
			throw e;
		}		
	}
	
	// ******************************************************************
	// �봽濡쒖떆�졇
	// INSERT, UPDATE, DELETE
	@Override
	public void callUpdateProcedure(String id, Object value) throws Exception{
		try {
			sqlSession.update(id, value);
		} catch (Exception e) {
			logger.error(e.toString());
			
			throw e;
		}
	}

	// SELECT : OUT �뙆�씪誘명꽣媛� SYS_REFCURSOR �씠�쇅�쓽 �븯�굹�쓽 �젅肄붾뱶(INTEGER �벑)
	@Override
	public <T> Map<String, T> callSelectOneProcedureMap(String id, Map<String, T> map) throws Exception{
		try {
			// select procedure 寃곌낵�뒗 map濡� 由ы꽩�븳�떎.
			sqlSession.selectOne(id, map);
		} catch (Exception e) {
			logger.error(e.toString());
			
			throw e;
		}
		
		return map;
	}
	
	// SELECT : OUT �뙆�씪誘명꽣媛� SYS_REFCURSOR(�븯�굹 �삉�뒗 �븯�굹 �씠�긽�쓽 �젅肄붾뱶)
	public <T> Map<String, T> callSelectListProcedureMap(String id, Map<String, T> map) throws Exception{
		try {
			// select procedure 寃곌낵�뒗 map濡� 由ы꽩�븳�떎.
			sqlSession.selectList(id, map);
		} catch (Exception e) {
			logger.error(e.toString());
			
			throw e;
		}
		
		return map;
	}
}
