package com.sp.app.common.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({
	 RepositoryConfiguration.class,
	 MybatisConfiguration.class,
})
public class SpringRootConfiguration {
}
